# Spectrum Analyzer Research for Radar Development
## 20-26 GHz K-band Spectrum Analyzers

**Date**: March 13, 2026  
**Purpose**: Radar development in K-band (20-26 GHz)  
**Budget Focus**: Affordable options preferred

---

## Table of Contents
1. [Quick Comparison Table](#quick-comparison-table)
2. [Budget Options (Under $25,000)](#budget-options)
3. [Mid-Range Options ($25,000-$50,000)](#mid-range-options)
4. [High-End Options ($100,000+)](#high-end-options)
5. [Portable/Handheld Options](#portable-handheld-options)
6. [Detailed Options & Configurations](#detailed-options-configurations)
7. [Recommendations for Radar Development](#recommendations-for-radar)

---

## Quick Comparison Table

| Model | Price (USD) | Frequency | Real-Time BW | DANL | Best For |
|-------|-------------|-----------|--------------|------|----------|
| **Anritsu MS2760A-0032** ⭐ | $6,850 | 9 kHz - 32 GHz | N/A | -132 dBm | Best handheld value |
| **Signal Hound SM200C** | $16,000 | 100 kHz - 20 GHz | 160 MHz | Good | Real-time, 10GbE |
| **Siglent SSA5085A** ⭐ | $20,000 | 9 kHz - 26.5 GHz | 40 MHz | -165 dBm | Best bench value |
| **Rigol RSA6265** ⭐ | $20,000 | 9 kHz - 26.5 GHz | 200 MHz | -163 dBm | Best real-time value |
| **Keysight N9000B CXA** | $20,000+ | 9 kHz - 26.5 GHz | N/A | -163 dBm | Entry Keysight |
| **R&S FSQ26 (used)** | $20,500 | 20 Hz - 26.5 GHz | N/A | -146 dBm | Premium refurb |
| **Ceyear 4051E** | $25,000 | 3 Hz - 26.5 GHz | N/A | Good | Chinese precision |
| **UNI-T UTS5026A** | $29,999 | 9 kHz - 26.5 GHz | N/A | -163 dBm | Good features |
| **Saluki CSA2026** | $15-25k | 100 kHz - 26.5 GHz | 40 MHz | -164 dBm | Compact USB |
| **Keysight N9938A FieldFox** | $34,818 | 100 kHz - 26.5 GHz | Optional | -155 dBm | Rugged handheld |
| **Ceyear 4082E** | $35-50k | 2 Hz - 26.5 GHz | Real-time | Excellent | 2 GHz analysis BW |
| **Keysight N9950B FieldFox** | $39,622 | 26.5 GHz | Optional | Good | Advanced handheld |
| **Signal Hound SM200B** | $40-60k | 100 kHz - 20 GHz | 160 MHz | Good | USB real-time |
| **Anritsu MS2090A-0726** | $40-60k | 9 kHz - 26.5 GHz | 150 MHz | -164 dBm | Portable real-time |
| **Tektronix RSA5126B (used)** | $100k+ | DC - 26.5 GHz | 165 MHz | Excellent | High-end real-time |
| **R&S FSW26** | $150k+ | 2 Hz - 26.5 GHz | 800 MHz | -148 dBm | Premium 5G/radar |
| **Tektronix RSA5126B (new)** | $263,630 | DC - 26.5 GHz | 165 MHz | Excellent | Top-tier real-time |

---

## Budget Options (Under $25,000)

### 1. Anritsu MS2760A-0032 ⭐ BEST HANDHELD VALUE
**Price**: $6,850  
**Frequency**: 9 kHz - 32 GHz (exceeds 26 GHz requirement!)

**Specifications:**
- Dynamic range: >103 dB @ 110 GHz
- DANL: -132 dBm to 70 GHz
- Phase noise: -116 dBc/Hz @ 10 kHz offset
- Accuracy: ±0.5 dB
- RBW: 1 Hz to 3 MHz
- Features: Up to 6 traces, 3 detectors, 12 markers
- Patented NLTL technology
- 3-year warranty
- Ultra-portable, pocket-sized
- USB-powered, PC/laptop/tablet controlled

**Where to Buy**: garangstore.com, testmart.com

**Accessories Available**:
- Anritsu 15NNF50-1.5C Test Port Cable (DC-6 GHz, N-type)

**Best For**: Unbeatable value for portable field testing, goes beyond 26 GHz to 32 GHz

---

### 2. Signal Hound SM200C ⭐ REAL-TIME ETHERNET
**Price**: ~$16,000  
**Frequency**: 100 kHz - 20 GHz (⚠️ Note: Only 20 GHz, not 26 GHz)

**Specifications:**
- Instantaneous BW: 160 MHz
- Dynamic range: 110 dB
- Sweep speed: 1 THz/sec
- RBW: 0.1 Hz to 3 MHz
- Interface: 10 Gigabit Ethernet (SFP+ fiber optic)
- Amplitude accuracy: ±2.0 dB (100 kHz - 6 GHz)
- Built-in GPS for timebase sync, I/Q timestamping, positioning
- GPS-disciplined OCXO: ±5×10⁻¹⁰ accuracy when locked
- Sub-octave preselector filters (20 MHz - 20 GHz)
- 160 MHz I/Q streaming over 10GbE

**Temperature Options:**
- Standard: 0°C to +50°C
- Option-1: -40°C to +65°C

**Accessories**:
- RF cables (26/40/50 GHz)
- SM200 Power Pack with LEMO cord
- Mounting brackets
- PN400 Accessory Kit ($1,100)
- RF limiters (30 MHz - 6 GHz)

**Software Included**: Spike spectrum analyzer software, full API access

**Where to Buy**: signalhound.com

**Best For**: Remote operation, distributed systems, real-time analysis
**Limitation**: Only goes to 20 GHz, not suitable if you need 26 GHz

---

### 3. Siglent SSA5085A ⭐ BEST BENCH SPECS PER DOLLAR
**Price**: €18,720 (~$20,000) / £15,777

**Specifications:**
- Frequency: 9 kHz - 26.5 GHz
- DANL: -165 dBm/Hz (with preamp) - BEST in this price range!
- Phase noise: -105 dBc/Hz
- RBW: 1 Hz to 10 MHz
- Screen: 12.1" multi-touch with HDMI output
- Standard tracking generator included
- Preamplifier included as standard

**Available Options:**

**Real-Time Analysis:**
- SSA5000-RTA1: 25 MHz Real-Time Bandwidth
- SSA5000-B40: Expands to 40 MHz Real-Time Bandwidth

**Advanced Measurements:**
- IQ data acquisition
- CHP (Channel Power)
- ACPR (Adjacent Channel Power Ratio)
- OBW (Occupied Bandwidth)
- TOI (Third Order Intercept)
- Harmonics analysis
- Spectrograms

**EMI Testing:**
- EMI pre-compliance with quasi-peak detector
- Near-field probe support

**Modulation Analysis:**
- AM, FM, PM demodulation
- ASK, FSK, MSK, PSK, DPSK, QAM analysis
- Bluetooth analysis
- Phase noise measurement

**Upgrade Path:**
- SSA5000-F5: Can upgrade SSA5083A (13.6 GHz) to SSA5085A (26.5 GHz)

**Where to Buy**: siglent.eu, siglent.co.uk, siglent.com

**Recommended Configuration for Radar**:
- Base unit (includes preamp) + SSA5000-B40 (40 MHz real-time) + Phase noise option
- **Total**: ~€21,000

**Best For**: Best sensitivity (DANL), excellent specs-per-dollar ratio, serious hobbyist to professional

---

### 4. Rigol RSA6265 ⭐ BEST REAL-TIME VALUE
**Price**: €18,799 (~$20,000) / £16,256-£16,596

**Specifications:**
- Frequency: 5 kHz - 26.5 GHz
- DANL: -143 dBm typical, -163 dBm with preamp
- Real-time BW: Up to 200 MHz
- Analysis BW: 80 MHz standard, 200 MHz optional
- RBW: 1 Hz minimum
- Screen: 10.1" touchscreen
- 5 working modes: GPSA, RTSA, VSA, EMI, ADM

**🎁 PROMOTION**: FREE 200 MHz analysis bandwidth upgrade through April 30, 2026!

**Available Options/Upgrades:**

**Bandwidth Expansions:**
- RSA6000-B200: 200 MHz Analysis Bandwidth (FREE until April 30, 2026)
- RSA6000-RB200: 200 MHz Real-Time Bandwidth

**Preamplifier:**
- RSA6000-P26: Preamplifier for 26.5 GHz
  - Improves DANL from -143 dBm to -163 dBm

**Application Software:**
- RSA6000-VSA: Vector Signal Analysis (essential for radar modulation)
- RSA6000-EMI: EMI Measurement Software
- RSA6000-ADM: Analog Demodulation Software

**Additional Modules:**
- RSA6000-AMK: Advanced Measurement Kit
- RSA6000-T08: 8.5 GHz Tracking Generator Output

**Standard Features**: USB, LAN, HDMI interfaces

**Where to Buy**: rigol-uk.co.uk, batronix.com, lambdaphoto.co.uk, rigolitalia.it

**Recommended Configuration for Radar**:
- Base unit + RSA6000-P26 (preamp) + Free 200MHz upgrade + RSA6000-VSA
- **Total**: ~€22,000

**Best For**: Real-time analysis on budget, captures radar pulses with 200 MHz BW, competitive alternative to Siglent

---

### 5. Keysight N9000B CXA
**Price**: $20,000-$30,000 (depending on configuration)

**Specifications:**
- Frequency: 9 kHz - 26.5 GHz (model N9000B-526)
- DANL: ~-163 dBm @ 1 GHz with preamplifier
- Phase noise: -110 dBc/Hz @ 10 kHz offset (1 GHz carrier)
- Resolution Bandwidth: 1 Hz to 8 MHz
- Analysis BW: 10 MHz standard, 25 MHz optional
- Amplitude accuracy: ±0.5 dB
- TOI: +17 dBm
- Dynamics: 162 dB typical
- Screen: 10.6" WXGA multi-touch display
- Dimensions: 368 x 426 x 177 mm

**Frequency Range Options (Choose ONE - NOT upgradeable):**
- N9000B-503: 9 kHz to 3.0 GHz
- N9000B-507: 9 kHz to 7.5 GHz
- N9000B-513: 9 kHz to 13.6 GHz
- **N9000B-526: 9 kHz to 26.5 GHz** ⭐ (required)

**Preamplifier Options:**
- N9000B-P03: 100 kHz to 3.0 GHz (+20 dB gain)
- N9000B-P07: 100 kHz to 7.5 GHz (+20 dB gain)
- N9000B-P13: 100 kHz to 13.6 GHz (+20 dB gain)
- **N9000B-P26: 100 kHz to 26.5 GHz (+20 dB gain)** ⭐

**Analysis Bandwidth:**
- 10 MHz (standard)
- N9000B-B25: 25 MHz Analysis Bandwidth

**Other Options:**
- N9000B-PFR: Precision Frequency Reference
- N9000B-FSA: Fine Step Attenuator (2 dB steps)
- N9000B-T03: 3 GHz Tracking Generator
- N9000B-T06: 6 GHz Tracking Generator
- N9000B-EDP: Enhanced Display Package
- N9000B-EMC: Basic EMC measurements
- N9000B-ESC: External Source Control

**Value Bundles:**
- "Best Value Bundle" includes: N9000B-526 + N9000B-P26 + N9000B-FSA + N9000B-PFR
- Saves ~20% vs buying individually

**Features:**
- Built-in tracking generator
- AM/FM demodulation
- EMI measurements
- Support for LoRa, NB-IoT, Bluetooth, 802.11
- LXI-C certification with LAN and USB interfaces

**Where to Buy**: Keysight dealers, datatec.eu

**Recommended Configuration for Radar**:
- N9000B-526 + N9000B-P26 + N9000B-B25 (or buy Best Value Bundle)
- **Total**: ~$35,000

**Best For**: Entry-level professional Keysight quality, brand reputation

---

### 6. Rohde & Schwarz FSQ26 (Refurbished)
**Price**: ~$20,500

**Specifications:**
- Frequency: 20 Hz - 26.5 GHz
- DANL: -146 dBm
- Analysis BW: Up to 120 MHz
- RBW: 1 Hz to 50 MHz
- Demodulation bandwidth: Up to 120 MHz
- Applications: WLAN, 3GPP, WiMAX

**Condition**: Refurbished with calibration & 1-year warranty

**Where to Buy**: aaatesters.com, testequipmenthq.com

**Best For**: Premium R&S performance at budget price, excellent dynamic range

---

### 7. Saluki CSA2026
**Price**: Est. $15,000-$25,000 (contact dealer)

**Specifications:**
- Frequency: 100 kHz - 26.5 GHz
- DANL: -164 dBm @ 1 GHz (with preamp)
- Analysis BW: 40 MHz
- RBW: 1 Hz minimum
- Size: Compact (175×150×64 mm)
- Interface: USB

**Where to Buy**: salukitec.com

**Best For**: Portable, space-constrained applications, compact USB-based

---

## Mid-Range Options ($25,000-$50,000)

### 8. Ceyear 4051E
**Price**: Est. $25,000-$35,000

**Specifications:**
- Frequency: 3 Hz - 26.5 GHz
- High precision
- Chinese military/aerospace brand heritage

**Where to Buy**: electronic-testinstruments.com

**Best For**: Budget performance from established Chinese manufacturer

---

### 9. UNI-T UTS5026A
**Price**: $29,999 (currently $1,000+ discount through March 31, 2026)

**Specifications:**
- Frequency: 9 kHz - 26.5 GHz
- DANL: -163 dBm/Hz
- Phase noise: -107 dBc/Hz @ 10 kHz
- Screen: 15.6" HD touchscreen (1920x1080)
- Sweep points: Up to 100,001 points
- Traces: 6 traces
- Analysis BW: 25 MHz standard, 40 MHz optional
- RBW: 1 Hz to 3 MHz in 10% steps, plus 4, 5, 6, 8 MHz options

**Included Features:**
- Advanced one-key measurement functions
- Analog demodulation (AM, FM, PM)
- EMI pre-compliance testing with near-field probes
- I/Q analysis capability
- Vector signal analysis (upcoming/optional)
- RF input, 10 MHz ref IN/OUT, external trigger
- HDMI, USB-Host, USB-Device, LAN, headphone jack

**Where to Buy**: uni-trendus.com, testequipmentdepot.com

**Recommended Configuration for Radar**:
- Base unit with 40 MHz option + Vector Signal Analysis

**Best For**: Advanced features on a budget, strong I/Q and vector analysis

---

### 10. Saluki 4025E Series Handheld
**Price**: Est. $25,000-$35,000

**Specifications:**
- Frequency: 9 kHz - 26.5 GHz
- DANL: -159 dBm (with preamp)
- Analysis BW: 40 MHz real-time
- Battery powered
- Handheld portable design

**Features:**
- Field strength measurement
- Interference analysis
- Analog demodulation

**Where to Buy**: salukitec.com

**Best For**: Field work, portable testing

---

### 11. Saluki S3302B Handheld
**Price**: Est. $30,000-$40,000

**Specifications:**
- Frequency: 9 kHz - 26.5 GHz
- DANL: -163 dBm @ 1 Hz RBW
- Screen: 8.4" LCD touch
- High-end handheld design

**Where to Buy**: salukitec.com

**Best For**: High-end portable testing

---

### 12. Keysight N9938A FieldFox
**Price**: $34,818

**Specifications:**
- Frequency: 30 kHz - 26.5 GHz (5 kHz for spectrum analysis)
- DANL: -155 dBm @ 1 GHz (with preamp)
- Analysis BW: 10 MHz
- Weight: 6.6 lb (3.0 kg)
- Accuracy: ±0.5 dB (no warm-up required)
- Battery: Rechargeable Li-ion
- Rugged handheld design

**Optional Configurations:**
- Option 220: Tracking Generator
- Option 235: Pre-amplifier
- Option 236: Interference Analyzer and Spectrogram
- Option 238: Spectrum Analyzer Time Gating (useful for radar!)
- Option 312: Channel Scanner
- Option 350: Real-Time Spectrum Analyzer (RTSA)
- Option 351: I/Q Analyzer (critical for radar!)

**Included Accessories:**
- Soft carrying case with backpack/shoulder straps
- AC/DC adapter, LAN cable, Quick reference guide

**Optional Accessories:**
- External battery chargers
- High-capacity batteries
- Various RF cables and adapters

**Where to Buy**: store.nwsnext.com, Keysight dealers

**Recommended Configuration for Radar**:
- Base N9938A + Option 235 (preamp) + Option 351 (I/Q) + Option 238 (time gating)

**Best For**: Field testing, telecom installation, antenna testing, rugged environments

---

### 13. Ceyear 4082E ⭐ BEST CHINESE HIGH-END
**Price**: $35,000-$50,000

**Specifications:**
- Frequency: 2 Hz - 26.5 GHz
- Analysis BW: 2 GHz (EXCELLENT for radar!)
- Phase noise: -134 dBc/Hz @ 10 kHz offset (outstanding!)
- Real-time spectrum analysis
- I/Q analysis capability
- Vector signal analysis (VSA)
- Comprehensive wireless communication signal analysis

**Where to Buy**: cc-globaltech.com

**Best For**: Best performance under $50k for radar, huge 2 GHz bandwidth captures complex waveforms, excellent phase noise

---

### 14. Keysight N9950B FieldFox
**Price**: $39,622

**Specifications:**
- Frequency: 26.5 GHz
- Enhanced version of N9938A
- Advanced handheld capabilities

**Where to Buy**: store.nwsnext.com

**Best For**: Advanced field testing

---

### 15. Signal Hound SM200B
**Price**: $40,000-$60,000

**Specifications:**
- Frequency: 100 kHz - 20 GHz (⚠️ Note: Only 20 GHz)
- Instantaneous BW: 160 MHz
- Dynamic range: 110 dB
- Sweep speed: 1 THz/sec
- Interface: USB 3.0
- I/Q capture: Calibrated, 40 MHz bandwidth, 2-second buffer
- Built-in GPS and GPS-disciplined OCXO

**Where to Buy**: signalhound.com

**Best For**: Real-time analysis with PC integration, excellent I/Q capture
**Limitation**: Only 20 GHz, not 26 GHz

---

### 16. Anritsu MS2090A-0726
**Price**: $40,000-$60,000

**Specifications:**
- Frequency: 9 kHz - 26.5 GHz
- Analysis BW: 22 MHz to 150 MHz options
- DANL: -164 dBm
- Max amplitude: +30 dBm
- Real-time analysis capability
- Portable design

**Where to Buy**: tehencom.com

**Best For**: Real-time field analysis, portable radar testing

---

## High-End Options ($100,000+)

### 17. Tektronix RSA5126B
**Price**: $100,000-$263,630 (full config)

**Specifications:**
- Frequency: DC - 26.5 GHz
- Real-time capture bandwidth: 25 MHz standard, up to 165 MHz
- Industry-leading real-time analysis
- Windows 10 operating system
- 4 GB acquisition memory
- Digital I/Q outputs

**Hardware Options:**

**Memory & Storage:**
- Opt. 53: 4 GB Memory (upgrade from 1 GB)
- Opt. WIN10RINT: 480 GB Internal Hard Drive
- Opt. WIN10REM: 480 GB Removable SSD

**Acquisition Bandwidth Upgrades:**
- Standard: 25 MHz
- Opt. B40: 40 MHz
- Opt. B85: 85 MHz
- Opt. B125: 125 MHz
- Opt. B16X: 165 MHz

**High Dynamic Range Options:**
- Opt. B85HD: 85 MHz HD (80 dB SFDR)
- Opt. B125HD: 125 MHz HD
- Opt. B16XHD: 165 MHz HD

**I/O Options:**
- Opt. 65: Real-time I and Q outputs
- Opt. 66: Analog zero span output
- Opt. 6566: Combined I/Q + zero span

**Software Analysis Modules:**

**General RF:**
- Opt. 11: RF Measurements
- Opt. 14: Noise Figure
- Opt. 60: Return Loss

**Pulse & Radar Analysis:**
- Opt. 20: Advanced Pulse Analysis ⭐ (essential for radar!)
- Opt. 54: Signal Classification

**Digital Modulation:**
- Opt. 21: General Purpose Digital Modulation
- Opt. 22: OFDM Analysis

**Wireless Standards:**
- Opt. 23, 34, 25: WLAN Analysis
- Opt. 27: Bluetooth LE/BR
- Opt. 28: LTE Downlink

**Other:**
- Opt. 10: Audio Analysis
- Opt. 26: APCO P25 Analysis

**Offline Analysis:**
- SignalVu-PC software
- RSAVu software

**Where to Buy**: axiomtest.com, valuetronics.com (used)

**Recommended Configuration for Radar**:
- Base RSA5126B + Opt. 53 (4GB RAM) + Opt. B16XHD (165 MHz HD) + Opt. 20 (pulse analysis) + Opt. 11 (RF measurements)

**Best For**: EMI/EMC labs, advanced R&D, interference hunting, pulsed radar analysis

---

### 18. Rohde & Schwarz FSW26 ⭐ INDUSTRY STANDARD
**Price**: $150,000+

**Specifications:**
- Frequency: 2 Hz - 26.5 GHz
- Analysis BW: Up to 2 GHz (internal, up to 8.3 GHz)
- Real-time BW: 800 MHz standard
- DANL: -148 to -156 dBm
- Phase noise: -140 dBc/Hz @ 10 kHz offset (1 GHz carrier)
- 2.4 million FFT/s
- POI (Point of Interest): 0.46 µs

**Bandwidth Options:**
- B512: 512 MHz Analysis Bandwidth Upgrade (€54,500)
- K512RE: 512 MHz Real-time option

**Frequency Extensions:**
- Extendable to 90 GHz internal
- Up to 500 GHz with external harmonic mixers

**Measurement Applications (Software Options):**
- K6: Pulse analysis (essential for pulsed radar!) ⭐
- K7: AM/FM/PULSE demodulation
- K70: Vector signal analysis
- K40: Phase noise measurement (critical for FMCW radar) ⭐

**Hardware Options:**
- B4: OCXO frequency precision
- B17: Digital baseband interface
- B21: External mixer connector interface
- B24: 30 dB preamplifier

**Accessories:**
- FS-SNS26: Noise source for calibration

**Where to Buy**: Rohde & Schwarz dealers, avalontest.com

**Recommended Configuration for Radar**:
- Base FSW26 + K6 (pulse) + K40 (phase noise) + B24 (preamp)
- **Total**: ~$180,000

**Best For**: Industry standard for radar development, 5G testing, best-in-class real-time analysis

---

## Critical Features for Radar Development

| Feature | Why Important | Minimum Spec | Best Options |
|---------|--------------|--------------|--------------|
| **Real-time BW** | Capture short pulses | ≥100 MHz | Rigol (200 MHz), Ceyear (2 GHz) |
| **Analysis BW** | Pulse spectrum analysis | ≥40 MHz | Ceyear (2 GHz), FSW26 (2 GHz) |
| **Phase noise** | Coherent radar, Doppler | ≤-110 dBc/Hz | Ceyear (-134), UNI-T (-107) |
| **DANL** | Weak return detection | ≤-160 dBm | Siglent (-165), Anritsu (-164) |
| **I/Q capture** | Modulation analysis | Essential | Most modern units |
| **VSA mode** | Waveform analysis | Highly recommended | Rigol, UNI-T, Ceyear |

---

## Recommendations for Radar Development

### Top Recommendation: Rigol RSA6265 (~€22,000)

**Why This is Best for K-band Radar Development:**

1. **200 MHz Real-Time Bandwidth** - Perfect for capturing radar pulses
   - FREE upgrade promotion through April 30, 2026
   - Wide enough for most pulsed radar applications

2. **VSA (Vector Signal Analysis) Mode** - Essential for radar modulation analysis
   - Analyze complex radar waveforms
   - Characterize pulse modulation

3. **-163 dBm DANL with Preamp** - Excellent sensitivity for weak radar returns

4. **Real-Time Spectrum Analysis** - Critical for radar pulse detection
   - RTSA mode captures transient signals
   - Won't miss short pulses

5. **Price/Performance Ratio** - 90% of $150k units at 1/7th the price

**Configuration**: Base unit + RSA6000-P26 (preamp) + Free 200MHz upgrade + RSA6000-VSA

---

### By Budget Category:

**Best Budget Choice ($20k):**
- **Rigol RSA6265** - Best real-time bandwidth, free 200 MHz upgrade, VSA mode

**Best Sensitivity ($20k):**
- **Siglent SSA5085A** - Best DANL (-165 dBm), add real-time option later

**Best Value Portable ($7k):**
- **Anritsu MS2760A-0032** - Incredible value, goes to 32 GHz, ultra-portable

**Best Mid-Range ($35-50k):**
- **Ceyear 4082E** - 2 GHz analysis bandwidth, -134 dBc/Hz phase noise

**Best Premium ($150k):**
- **Rohde & Schwarz FSW26** - Industry standard, 800 MHz real-time, 2 GHz analysis

---

### By Radar Type:

**1. Pulsed Radar** → Need wide real-time BW (≥100 MHz)
   - **Best**: Rigol RSA6265, Ceyear 4082E, R&S FSW26
   - **Budget**: Rigol RSA6265 with 200 MHz real-time

**2. FMCW/CW Radar** → Phase noise critical, continuous sweep
   - **Best**: Ceyear 4082E (-134 dBc/Hz), R&S FSW26 (with K40 option)
   - **Budget**: UNI-T UTS5026A (-107 dBc/Hz)

**3. Phased Array Radar** → Need I/Q, vector analysis
   - **Best**: Rigol RSA6265 (VSA mode), Tektronix RSA5126B
   - **Budget**: Rigol RSA6265 with VSA option

**4. Automotive Radar (24 GHz)** → Standard K-band testing
   - **Best**: Any $20k option (Rigol, Siglent, Keysight N9000B)
   - **Budget**: Siglent SSA5085A for best sensitivity

**5. Military/Aerospace Radar** → Need best specs, calibration
   - **Best**: R&S FSW26, Tektronix RSA5126B
   - **Mid-range**: Keysight N9000B CXA for calibration standards

---

### Where to Buy:

**New Equipment:**
- **Siglent**: siglent.eu, siglent.co.uk, siglent.com
- **UNI-T**: uni-trendus.com, testequipmentdepot.com
- **Rigol**: rigol-uk.co.uk, batronix.com, lambdaphoto.co.uk
- **Saluki**: salukitec.com
- **Keysight**: Contact authorized dealers
- **Signal Hound**: signalhound.com
- **Ceyear**: electronic-testinstruments.com, cc-globaltech.com

**Used/Refurbished:**
- valuetronics.com
- transcat.com
- aaatesters.com
- testequipmenthq.com
- axiomtest.com

---

## Key Takeaways

1. **Best Overall Value for Radar**: Rigol RSA6265 at €20k with free 200 MHz upgrade

2. **Best Budget Handheld**: Anritsu MS2760A-0032 at $6,850 (goes to 32 GHz!)

3. **Best Sensitivity**: Siglent SSA5085A with -165 dBm DANL

4. **Best Performance Under $50k**: Ceyear 4082E with 2 GHz analysis bandwidth

5. **Industry Standard**: Rohde & Schwarz FSW26 at $150k+ for professional labs

6. **Critical for Radar**: Look for real-time bandwidth ≥100 MHz, phase noise ≤-110 dBc/Hz, and VSA/I/Q capabilities

7. **Timing**: Act before April 30, 2026 for Rigol's free 200 MHz upgrade promotion!

---

**Document Created**: March 13, 2026  
**Research Focus**: K-band (20-26 GHz) spectrum analyzers for radar development  
**Budget Priority**: Affordable options with professional performance
